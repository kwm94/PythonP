# File name: feet_to_meters
# Name: Kit Wei Min
# Description: Converts length from feet to meters

# Prompts for the length in feet
feet = float(input("Length in feet = "))

# Converts feet to meters
meter = feet * 0.305

# Displays result
print("Length in meters = {0:<10.3f}".format(meter))

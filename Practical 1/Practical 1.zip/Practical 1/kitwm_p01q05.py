# Filename : Upper_to_lower
# Name : Kit Wei Min
# Description : Converts uppercase letter(s) to a lowercase letter(s)

# Prompts for uppercase letters
letter = input("Type in an uppercase letter(s): ")

# Displays it in lowercase
print(letter.lower())



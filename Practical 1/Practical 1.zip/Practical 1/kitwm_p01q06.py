# Filename : ASCII_character
# Name : Kit Wei Min
# Description : Displays the character of an ASCII code.


# Prompts for an ASCII code

code = int(input("Enter ASCII code: "))

# Converts ASCII code

character = chr(code)

print(character)
